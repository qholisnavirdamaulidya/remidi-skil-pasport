<body>
    <form method="POST" enctype="multipart/fprm-data" class="box">
        <h2>ID</h2>
        <input type="number" name="id" placehoder="id" value=<?php echo isset($row['id']) ? $row['id']: '';?>>
        <h2>Nama</h2>
        <input type="text" name="nama"  placehoder="nama" value=<?php echo isset($row['nama']) ? $row['nama']: '';?>>
        <h2>Tempat Lahir</h2>
        <input type="text" name="tl"  placehoder="tempat lahir" value=<?php echo isset($row['tplahir']) ? $row['tplahir']: '';?>>
        <h2>Tanggal Lahir</h2>
        <input type="text" name="tgl"  placehoder="tanggal lahir" value=<?php echo isset($row['tglahir']) ? $row['tglahir']: '';?>>
        <h2>Alamat</h2>
        <input type="text" name="alamat"  placehoder="alamat" value=<?php echo isset($row['alamat']) ? $row['alamat']: '';?>>
        <h2>Hobi</h2>
        <input type="text" name="hobi"  placehoder="hobi" value=<?php echo isset($row['hobi']) ? $row['hobi']: '';?>>
        <h2>Cita-Cita</h2>
        <input type="text" name="cita"  placehoder="cita" value=<?php echo isset($row['cita']) ? $row['cita']: '';?>>
        <h2>Jumlah Saudara</h2>
        <input type="text" name="jmsaudara"  placehoder="jumlah saudara" value=<?php echo isset($row['jm_saudara']) ? $row['jm_saudara']: '';?>>
        <h2>ID Kelas</h2>
        <input type="text" name="idk"  placehoder="ID Kelas" value=<?php echo isset($row['idkelas']) ? $row['idkelas']: '';?>>
        <h2>ID Agama</h2>
        <input type="text" name="ida"  placehoder="ID Agama" value=<?php echo isset($row['idagama']) ? $row['idagama']: '';?>>
        <br><br>
        <input type="submit" name="konfirmasi"value="konfirmasi" class="btn">
        <button class="btn"><a href="\biodata_mirna\tampildata.php">kembali</a></button>
</form>
</body>
<?php
include 'koneksi.php';
if (isset($_POST['konfirmasi'])){
    mysqli_query($koneksi,"update siswa set id='$_POST[id]',nama='$_POST[nama]',tplahir='$_POST[tl]',tglahir='$_POST[tgl]',
    alamat=$_POST[alamat]',hobi='$_POST[hobi]',cita_cita='$_POST[cita]',jm_saudara='$_POST[jmsaudara]',idkelas='$_POST[idk]',idagama='$_POST [id]');
    where id=$_GET[id]");
}
?>
    
    
        
        

