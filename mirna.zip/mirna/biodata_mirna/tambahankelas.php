<body class="bd">
    <form method="POST" enctype="multipart/form-data" class="box">
        <h2>ID</h2>
        <input type="number" name="id" placeholder="ID">
        <h2>Nama kelas</h2>
        <input type="number" name="namak" placeholder="Nama Kelas">
        <h2>Kompetensi</h2>
        <input type="text" name ="kompetensi" placeholder="kompetensi">
        <h2>Tahun Pelajaran</h2>
        <input type="number" name="tp" placeholder="Tahun pelajaran">
        <h2>Keterangan</h2>
        <input type="text" name="Keterangan" placeholder="Keterangan">
        <br><br>
        <input type="submit" name="konfirmasi"value="konfirmasi" class="btn">
        <button class="btn"><a href="\biodata_mirna.php">kembali</a></button>
</form>
</body>
<?php
include 'koneksi.php';
if (isset($_POST['konfirmasi'])){
    mysqli_query($koneksi,"insert into kelas set ud='$_POST[id]',namakelas='$_POST[namakelas]',kompetens='$_POST[kompetensi]',
    tahun_pelajaran='$_POST[tp]',keterangan='$_POST[keterangan]'");
}
?>