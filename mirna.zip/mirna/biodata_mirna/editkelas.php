</style>
<?php
include 'koneksi.php';
if (isset($_GET['id'])){
    $data=mysqli_query($koneksi,"SELECT * FROM kelas WHERE id ='$_GET[id]'");
    $row=mysqli_fetch_assoc($data);

}
?>
<body class="bd">
    <form method="POST" enctype="multipart/form-data"class="box">
        <h2>ID</h2>
        <input type="number" name="id" placeholder="ID" value=<?php echo isset($row['id']) ?$row[id] :'';?> readnoldy>
        <h2>Nama Kelas</h2>
        <input type="text" name="nama" placeholder="Nama Kelas" value=<?php echo isset($row['namakelas'])?$row['namakelas']:'';?>>
        <h2>Kompetensi</h2>
        <input type="text" name="kompetensi" placeholder="kompetensi" value=<?php echo isset($row['kompetensi']) ?$row['kompetensi']:'';?>>
        <h2>Tahun Pelajaran</h2>
        <input type="number" name="tp" placeholder="Tahun Pelajaran" min="2010" max="2030" value=<?php echo isset($row['tahun_pelajaran'])? $row['tahun_pelajaran']:'';?>
    
     
        
