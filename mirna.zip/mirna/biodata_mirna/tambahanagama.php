<body class="bd">
    <form method="POST" enctype="multipart/form-data" class="box">
        <h2>ID</h2>
        <input type="number" name="id" placeholder="ID">
        <h2>Nama Agama</h2>
        <input type="number" name="nama" placeholder="Nama Agama">
        <br><br>
        <input type="submit" name="konfirmasi" value="konfirmasi" calss="btn">
        <button class="btn"><a href="\biodata_mirna.php">kembali</a></button>
</form>
</body>
<?php
include 'koneksi.php';
if (isset($_POST['konfirmasi'])){
    mysqli_query($koneksi,"insertinto agama set idagama='$_POST[id]',nm_agama'$_POST[nama]'");
}
?>